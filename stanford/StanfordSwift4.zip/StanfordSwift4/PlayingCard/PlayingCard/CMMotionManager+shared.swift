//
//  CMMotionManager+shared.swift
//  PlayingCard
//
//  Created by Ivica Petrsoric on 03/03/2018.
//  Copyright © 2018 Ivica Petrsoric. All rights reserved.
//

import CoreMotion

extension CMMotionManager {
    
    static var shared = CMMotionManager()
}
