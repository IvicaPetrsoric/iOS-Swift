//
//  ViewController.swift
//  FirebaseSocialLogin
//
//  Created by ivica petrsoric on 25/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import Firebase
import GoogleSignIn

class ViewController: UIViewController, FBSDKLoginButtonDelegate, GIDSignInUIDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupFBButtons()
    
        setupGoogleButtons()
    }
    
    private func setupFBButtons() {
        let loginButton = FBSDKLoginButton()
        view.addSubview(loginButton)
        loginButton.frame = CGRect(x: 16, y: 50, width: view.frame.width - 32, height: 50)
        loginButton.delegate = self
        loginButton.readPermissions = ["email", "public_profile"]
        
        let customFBButton = UIButton()
        customFBButton.backgroundColor = .blue
        customFBButton.frame = CGRect(x: 16, y: 120, width: view.frame.width - 32, height: 50)
        customFBButton.setTitle("Custom FB Login Here", for: .normal)
        customFBButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        customFBButton.setTitleColor(.white, for: .normal)
        view.addSubview(customFBButton)
        
        customFBButton.addTarget(self, action: #selector(handleCustomFBLogin), for: .touchUpInside)
    }
    
    private func setupGoogleButtons(){
        // goolge sign in
        let googleButton = GIDSignInButton()
        googleButton.frame = CGRect(x: 16, y: 116 + 66, width: view.frame.width - 32, height: 50)
        view.addSubview(googleButton)
        
        let customButton = UIButton(type: .system)
        customButton.frame = CGRect(x: 16, y: 116 + 66 + 66, width: view.frame.width - 32, height: 50)
        customButton.backgroundColor = .orange
        customButton.setTitle("Custom google sign in", for: .normal)
        customButton.addTarget(self, action: #selector(handleCustomGooglSing), for: .touchUpInside)
        customButton.setTitleColor(.white, for: .normal)
        customButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        view.addSubview(customButton)
        
        GIDSignIn.sharedInstance().uiDelegate = self
    }
    
    @objc func handleCustomGooglSing(){
        GIDSignIn.sharedInstance().signIn()
    }
    
    
    @objc func handleCustomFBLogin(){
        FBSDKLoginManager().logIn(withReadPermissions: ["email", "public_profile"], from: self) { (result, err) in
            if let err = err{
                print("Failed to start graph request:",err)
                return
            }
            
            //            print(result?.token.tokenString)
            
            self.showEmailAddress()
        }
    }

    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if let error = error {
            print(error)
            return
        }
        
        print("Successfully logged in with ")
        
        showEmailAddress()
    }
    
    func showEmailAddress(){
        guard let accessToken = FBSDKAccessToken.current().tokenString else { return }
        let credentials = FacebookAuthProvider.credential(withAccessToken: accessToken)

//        Auth.auth().signInAndRetrieveData(with: credentials) { (user, err) in
//            if let err = err{
//                print("Something went wrong with our FB user:",err)
//                return
//            }
//            
//            print("Successfully logged in with our user: ", user as Any)
//        }
        Auth.auth().signIn(with: credentials) { (user, err) in
            if let err = err{
                print("Something went wrong with our FB user:",err)
                return
            }

            print("Successfully logged in with our user: ", user as Any)
        }
        
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, email"]).start { (connection, result, err) in
            
            if err != nil{
                print("Failed for graph request")
                return
            }
            
            print(result as Any)
        }
    }
    

}

