//
//  CoreDataManager.swift
//  RealmCRUD
//
//  Created by ivica petrsoric on 11/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import CoreData
import RealmSwift

class CoreDataManager {
    
    static let shared = CoreDataManager()
    
    fileprivate let persistantContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MyCoreData")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error {
                fatalError("Loading of store failed \(error)")
            }
        })
        return container
    }()
    
    func create(currentLine: PickUpLineCD) {
        let context = persistantContainer.viewContext
        
        let newLine = NSEntityDescription.insertNewObject(forEntityName: "PickUpLineCD", into: context) as! PickUpLineCD
        newLine.line = currentLine.line
        newLine.score = currentLine.score
        newLine.email = currentLine.email

        do {
            try context.save()
        } catch let createErr {
            print("CoreData failed to create with err:", createErr)
        }
    }
    
    func read() -> [PickUpLineCD] {
        let context = persistantContainer.viewContext
        
        let fetchRequest = NSFetchRequest<PickUpLineCD>(entityName: "PickUpLineCD")
        
        do {
            return try context.fetch(fetchRequest)
        } catch let readErr {
            print("CoreData read err: ", readErr)
            return []
        }
    }
    
    func update(updateLine: PickUpLineCD) {
        let context = persistantContainer.viewContext
        
        do {
            try context.save()
        } catch let updateErr {
            print("CoreData update err: ", updateErr)
        }
    }
    
    func delete(line: PickUpLineCD) {
        let context = persistantContainer.viewContext
        context.delete(line)
        
        do {
            try context.save()
        } catch let deleđErr {
            print("CoreData failed to delete: ", deleđErr)
        }
    }
    
}
