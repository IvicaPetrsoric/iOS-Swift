//
//  RealmService.swift
//  RealmCRUD
//
//  Created by ivica petrsoric on 07/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import Foundation
import RealmSwift

class RealmService {
    
    private init() {}
    
    static let shared = RealmService()
    
    var realm = try! Realm()
    
    func read<T: Object>(_ object: T.Type, predicate: NSPredicate? = nil) -> Results<T> {
        if let predicateFormat = predicate {
            return realm.objects(object).filter(predicateFormat)
        } else {
            return realm.objects(object)
        }
    }
    
//    public func objects<Element: Object>(_ type: Element.Type) -> Results<Element> {
//        return Results(RLMGetObjects(rlmRealm, type.className(), nil))
//    }
    
    func create<T: Object>(_ object: T) {
        do {
            try realm.write {
                realm.add(object)
            }
        } catch {
            post(error)
        }
    }
    
    func update<T: Object>(_ object: T, with dictionary: [String: Any?]) {
        do {
            try realm.write {
                for (key, value) in dictionary {
                    object.setValue(value, forKey: key)
                }
            }
        } catch {
            post(error)
        }
    }
    
    func delete<T: Object>(_ object: T) {
        do {
            try realm.write {
                realm.delete(object)
            }
        } catch {
            post(error)
        }
    }
    
    func post(_ error: Error) {
        NotificationCenter.default.post(name: Notification.Name("RealmError"), object: error)
    }
    
    func observerRealmErrors(in vc: UIViewController, completion: @escaping (Error?) -> ()) {
        NotificationCenter.default.addObserver(forName: Notification.Name("RealmError"), object: nil, queue: nil) { (notification) in
            completion(notification.object as? Error)
        }
    }
    
    func stopObservingErrors(in vc: UIViewController) {
        NotificationCenter.default.removeObserver(vc, name: Notification.Name("RealmError"), object: nil)
    }
    
}


