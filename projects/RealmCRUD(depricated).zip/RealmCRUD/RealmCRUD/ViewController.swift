//
//  ViewController.swift
//  RealmCRUD
//
//  Created by ivica petrsoric on 07/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import UIKit
import RealmSwift


class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var pickUpLines: Results<PickUpLine>!
    var notificationToken: NotificationToken?
    
    var lines = [PickUpLineCD]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        fetchRealmData()
        fetchCoreData()
    }
    
    fileprivate func fetchRealmData() {
        let realm = RealmService.shared.realm
        
        let predicate = NSPredicate(format: "\(PickUpLine.Attributes.line.rawValue) == %@", "123")
        //        pickUpLines = realm.objects(PickUpLine.self).filter(predicate)
        pickUpLines = RealmService.shared.read(PickUpLine.self, predicate: predicate)
        
        //        pickUpLines = realm.objects(PickUpLine.self)
        
        print("Data in DB: ", pickUpLines.isEmpty ? "NO DATA" : pickUpLines)
        
        notificationToken = realm.observe { (notification, realm) in
            self.tableView.reloadData()
        }
        
        RealmService.shared.observerRealmErrors(in: self) { (error) in
            // handle error
            print(error ?? "no error detexted")
        }
    }
    
    fileprivate func fetchCoreData() {
        self.lines = CoreDataManager.shared.read()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("VIEW WILL DISAPPEAR!")
        notificationToken?.invalidate()
        RealmService.shared.stopObservingErrors(in: self)
    }

    @IBAction func onAddTapped(_ sender: UIBarButtonItem) {
        AlertService.addAlert(in: self) { (line, score, email) in
//            print(line, score, email)
            let newPickUpLine = PickUpLine(line: line, score: score, email: email)
            RealmService.shared.create(newPickUpLine)
//            let dict: [String: Any?] = ["line": line,
//                                        "score": score,
//                                        "email": email]
//            RealmService.shared.update(newPickUpLine, with: dict)

        }
    }
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return pickUpLines.count
        return lines.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PickUpLineCell") as! PickUpLineCell 
        let pickUpLine = pickUpLines[indexPath.row]
        cell.configure(with: pickUpLine)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 63
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Sdelected")
        
        let pickupLine = pickUpLines[indexPath.row]
        AlertService.updateAlert(in: self, pickUpLine: pickupLine) { (line, score, email) in
            let dict: [String: Any?] = ["line": line,
                                        "score": score,
                                        "email": email]
            RealmService.shared.update(pickupLine, with: dict)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }
        print("Delete")
        let pickUpLine = pickUpLines[indexPath.row]
        RealmService.shared.delete(pickUpLine)
    }
}

