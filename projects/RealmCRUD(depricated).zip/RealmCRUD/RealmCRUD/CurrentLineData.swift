//
//  CurrentLineDAta.swift
//  RealmCRUD
//
//  Created by ivica petrsoric on 11/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import Foundation

struct CurrentLineData {
    
    let line: String
    let score: Int
    let email: String
}
