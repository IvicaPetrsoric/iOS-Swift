//
//  PickUpLineCell.swift
//  RealmCRUD
//
//  Created by ivica petrsoric on 07/07/2018.
//  Copyright © 2018 ivica petrsoric. All rights reserved.
//

import UIKit

class PickUpLineCell: UITableViewCell {
    
    @IBOutlet weak var lineLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    func configure(with pickUpLine: PickUpLine) {
        lineLabel.text = pickUpLine.line
        scoreLabel.text = pickUpLine.scoreString()
        emailLabel.text = pickUpLine.email
    }

}
