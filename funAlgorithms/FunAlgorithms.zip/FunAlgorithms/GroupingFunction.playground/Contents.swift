//: Playground - noun: a place where people can play

import UIKit

struct Person{
    let firstName: String
    let lastName: String
    let age: Int
}

let people = [
    Person(firstName: "Michael", lastName: "Jordan", age: 55),
    Person(firstName: "Kobe", lastName: "Bryant", age: 42),
    Person(firstName: "Magic", lastName: "Johnson", age: 61),
    Person(firstName: "Steph", lastName: "Curry", age: 28),
    Person(firstName: "Lebron", lastName: "James", age: 34),
    Person(firstName: "Kevin", lastName: "Durant", age: 28)
]

// perform grouping
let groupedDictionary = Dictionary(grouping: people) { (person) -> Int in
    return person.age
}

let groupedDictionaryLastName = Dictionary(grouping: people) { (person) -> Character in
    return person.lastName.first!
}

var groupedPople = [[Person]]()

let keys = groupedDictionaryLastName.keys.sorted()
keys.forEach { (key) in
    groupedPople.append(groupedDictionaryLastName[key]!)
}

groupedPople.forEach({
    $0.forEach({print($0)})
    print("---------")
})
