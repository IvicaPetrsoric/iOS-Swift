//: Playground - noun: a place where people can play

import UIKit

let startSentence = "madam anna kayak notapalindrome anna Civic racecar"

// implement a function that will tell me for each palindrom, how many time it occurs. For examlle:
// ["Civic":1, "madam": 1]

// prvo odrditi ako je palindrom, tj čita se s obje strane isto
let counts = palindromeCounts(sentence: startSentence)
print(counts)

func palindromeCounts(sentence: String) -> [String: Int]{
//    print(sentence)
    var counts = [String: Int]()
    
    let words = sentence.components(separatedBy: " ")
    words.forEach { (word) in
        //print(word)
        
        if isPalindrome(word: word){
            let count = counts[word] ?? 0
            counts[word] = count + 1
            print("Found palindrome",word)
        }
    }
    
    return counts
}

fileprivate func isPalindrome(word: String) -> Bool{
    let characters = Array(word.lowercased())
    var currentIndex = 0
    
    // usporedivanje prvog i zadnjeg i tako prema sredini
    while currentIndex < characters.count / 2{
        if characters[currentIndex] != characters[characters.count - currentIndex - 1]{
            return false
        }
        
        currentIndex += 1
    }
    
    return true
}
