//: Playground - noun: a place where people can play

import UIKit

let now = Date().description
let pastDate = Date(timeIntervalSinceNow: -65 * 60 * 24 * 7)

extension Date{
    func timeAgoDisplay() -> String{
        let secondsAgo = Int(Date().timeIntervalSince(self))
        
        let minute = 60
        let hour = 60 * minute
        let day = 24 * hour
        let week = 7 * day
        
        
        if secondsAgo < minute{
            return "\(secondsAgo) seconds ago"
        }
        else if secondsAgo < hour {
            return "\(secondsAgo / minute) minutes ago"
        }
        // hours
        else if secondsAgo < day{
            return "\(secondsAgo / hour) hours ago"
        }
            // days
        else if secondsAgo < week{
            return "\(secondsAgo / day) days ago"

        }
        // weks
        return "\(secondsAgo / week) weks ago"

        
        /*
         // optimizacija!
         if secondsAgo < 60{
         return "\(secondsAgo) seconds ago"
         }
         else if secondsAgo < 60 * 60 {
         return "\(secondsAgo / 60) minutes ago"
         }
         // hours
         else if secondsAgo < 60 * 60 * 24{
         return "\(secondsAgo / 60 / 60) hours ago"
         }
         // days
         else if secondsAgo < 60 * 60 * 24 * 7{
         return "\(secondsAgo / 60 / 60 / 24) days ago"
         
         }
         // weks
         return "\(secondsAgo / 60 / 60 / 24 / 7) weks ago"
         */
        
    }
}

pastDate.timeAgoDisplay()
