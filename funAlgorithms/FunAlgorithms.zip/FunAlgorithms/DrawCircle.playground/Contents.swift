//: Playground - noun: a place where people can play

import UIKit

class CircleView: UIView{
    
    override func draw(_ rect: CGRect) {
        // fancy drawing
        
        let path = UIBezierPath()
//        path.move(to: .zero)
        
        // x*x + y*y = r* r
        // cos(theta) = x / r ==> x = r * cos(theta)
        // sin(theta) = y / r ==> y = r * sin(theta)
        
        let radius: Double = Double(rect.width) * 0.4
        
        let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
        path.move(to: CGPoint(x: center.x + CGFloat(radius), y: center.y))
 
        for i in stride(from: 0, to: 361.0 , by: 60){ // 180.0 pretvara odmah u double
            
            // radian treba a ne stupnjeve! radius = degre * PI / 180
            let radiands = i * Double.pi / 180
            
            let x = Double(center.x) + radius * cos(radiands)
            let y = Double(center.y) + radius * sin(radiands)
            
            //print(i)
            path.addLine(to: CGPoint(x: x, y: y))
            print(x,y)
        }
        
        
//        path.addLine(to: CGPoint(x: 100, y: 100))
        UIColor.red.setStroke()
        path.lineWidth = 5
        path.stroke()
    }
}

let view = CircleView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
view.backgroundColor = .white
