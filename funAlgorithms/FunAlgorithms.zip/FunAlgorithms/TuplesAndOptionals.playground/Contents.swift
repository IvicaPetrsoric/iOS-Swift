//: Playground - noun: a place where people can play

import UIKit

let regularVariable = 1

let person = ("Billy", "Bob", "johnson")
print(person.0, person.1, person.2)

let p = (firstName: "Billy", middleName: "Bob", lastName: "Johnson")
print(p.lastName)

func multiply(x: Int, y: Int) -> Int{
    return x * y
}

multiply(x: 4, y: 3)

func divide(x: Int, y: Int) -> (Int,Int){
    return (x / y, x % y)
}

divide(x: 7, y: 2)



// try optionals in tuples
func topTwoLongestNames(names: [String]) -> (String?, String?){
    
    if names.isEmpty{
        return (nil, nil)
    }
    
    // sort
    let sorted = names.sorted { (x, y) -> Bool in
        x.count > y.count
    }
    
    print(sorted)
    
    if sorted.count == 1{
        return (sorted[0], nil)
    }
    
    return (sorted[0],sorted[1])
}

//topTwoLongestNames(names: ["Mike", "Bill", "Steve", "Samantha"])
topTwoLongestNames(names: ["Mike"])



