//: Playground - noun: a place where people can play

import UIKit

// Write a function that calculates my ending balance on my savings accout for X number of YEARS

// a) Simple Interest


let startingBalance = 10000.0

let numbOfYears = 25
let APY = 0.013 // Annual Percentage Yield, 10 % interest rate

let ending =  Double(numbOfYears) * startingBalance * APY + startingBalance

// b) Compund Interest

var runningBalance = startingBalance
//runningBalance *= 1 + APY
//runningBalance = runningBalance * (1 + APY)
//runningBalance = runningBalance * APY + runningBalance
//runningBalance = runningBalance * APY + runningBalance
//runningBalance = runningBalance * APY + runningBalance
//runningBalance = runningBalance * APY + runningBalance


// unitl you get this 30 times-....
func calcualteCompundInterestOfBalance(starting: Double, numberOfYears: Int) -> Double{
    var rb = starting
    (0..<numberOfYears).forEach { (_) in
        rb *= (1 + APY)
    }
    return rb
}

calcualteCompundInterestOfBalance(starting: 10000, numberOfYears: 25)

//(0..<30).forEach { (i) in
//    print(i)
//    runningBalance *= 1 + APY
//}
//print(runningBalance)













