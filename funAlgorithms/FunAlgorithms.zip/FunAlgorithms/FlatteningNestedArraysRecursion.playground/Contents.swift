//: Playground - noun: a place where people can play

import UIKit

// nested array [1] -> [1]
// [1,2 ,3] -> [1, 2, 3]
// [1, [2]] -> [1, 2]
// [1, [2, [3, 4]]] -> [1, 2, 3, 4]

func flatternArray(nestedArray: [Any]) -> [Int]{
    
    var myFlattenedArray = [Int]()
    
    for element in nestedArray{
        print(element)
        if element is Int{
            myFlattenedArray.append(element as! Int)
        }
        else if element is [Any]{
            print(element)
            let resursionResult = flatternArray(nestedArray: [element])
            
            for num in resursionResult{
                myFlattenedArray.append(num)
            }
            //            let nestedElements = element as! [Int]
            //            for num in nestedElements{
            //                myFlattenedArray.append(num)
            //            }
        }
    }
    return myFlattenedArray
}


let result = flatternArray(nestedArray: [1, [2, [3 , 4]]])
print("Result: ",result)










