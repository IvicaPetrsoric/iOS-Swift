//: Playground - noun: a place where people can play

import UIKit

// 1. Implement summation of an Array of Integers
func summation(for numbers: [Int]) -> Int{
    var sum = 0
    
//    numbers.forEach { (num) in
//        sum += num
//    }
    
    numbers.forEach { sum += $0}
    
    return sum
}

summation(for: [1, 2, 3, 4])

//let mySum = [1,2,3,4,5].reduce(0) { (res, next) -> Int in
//    return res + next
//}

let mySum = [1,2,3].reduce(0,{$0 + $1})
print("mySum:", mySum)

// 2. Implement the product of an Array of Integers
func product(for numbers: [Int]) -> Int{
    var product = 1
    
    numbers.forEach { product *= $0}
    
    return product
}

product(for: [1, 2, 4, 6])

let myProduct = [1, 2, 4, 6].reduce(1, {$0 * $1})

// 3. Transform an Array of Strings into a sentence
let facts = ["Brian", "is", "the", "boom"]
let trueFasts = facts.reduce("", {$0 + $1 + " "})
