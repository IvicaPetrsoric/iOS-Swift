//: Playground - noun: a place where people can play

import UIKit

var sampleSentence = "Lets start today by completing a very interesting challenge"

func reverseWordsInSentence(sentence: String) -> String{
    
    let allWords = sampleSentence.components(separatedBy: " ")
    var newSentence = ""
    
//    for word in allWords{
//
//
//        print(word)
//
//        if newSentence != ""{
//            newSentence += " "
//        }
//
//        let reversedWord = String(word.characters.reversed())
//
//        newSentence += reversedWord
//    }
    
    for index in 0...allWords.count - 1{
        let word = allWords[index]
        
        if newSentence != ""{
            newSentence += " "
        }
        
        if index % 2 == 1{
            let reversedWord = String(word.characters.reversed())
            newSentence += reversedWord.stringByRemovingVowels()

        }else{
            newSentence += word.stringByRemovingVowels()
        }
    }
    return newSentence
}

extension String{
    func stringByRemovingVowels() -> String{
        var newWord = self
        for vowel in ["a", "e", "i", "o", "u"]{
            newWord = newWord.replacingOccurrences(of: vowel, with: "")
            
        }
        return newWord
    }
}

reverseWordsInSentence(sentence: sampleSentence)










