import UIKit

func shuffleArray<T>(nums: [T]) -> [T] {
    var mutableCopfyOfNums = nums
    var suffledArraySoFar = [T]()
    
    while mutableCopfyOfNums.count > 0 {
        let randIndex = Int.random(in: 0..<mutableCopfyOfNums.count)
        let removedItem = mutableCopfyOfNums.remove(at: randIndex)
        suffledArraySoFar.append(removedItem)
    }
    
    return []
}

let numbers = [3, 5, 2, 1]
let _ = shuffleArray(nums: numbers)

// softball interview q

func sum(numbers: [Int]) -> Int {
    return numbers.reduce(0, { $0 + $1})
    
//    var res = 0
//
//    numbers.forEach { (num) in
//        res += num
//    }
//    return res
}

sum(numbers: [1,2,3])

extension Array where Element: Numeric{
    
    func sum() -> Element {
        return self.reduce(0, {$0 + $1})
    }
}

[0.1, 0.2].sum()

let floats: [CGFloat] = [1.0, 0.2]
floats.sum()

extension Array where Element == String {
    
    func contatinate() -> String {
        return self.reduce("", {$0 + $1})
    }
}

["asd", "asd"].contatinate()
