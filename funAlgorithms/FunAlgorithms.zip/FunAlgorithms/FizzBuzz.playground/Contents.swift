//: Playground - noun: a place where people can play

import UIKit

let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

var oneThousandNumbers = [Int]()
for i in 1...1000{
    oneThousandNumbers.append(i)
}

for num in oneThousandNumbers{
    // modul 3 i 5 je isto ko modul od 15!
    if num % 3 == 0{
        if num % 5 == 0{
            print("\(num) fizzBuzz")
        }else{
            print("\(num) fizz")
        }
    }
    else if num % 5 == 0{
        print("\(num) buzz")
    }
    else{
        print(num)
    }
}
