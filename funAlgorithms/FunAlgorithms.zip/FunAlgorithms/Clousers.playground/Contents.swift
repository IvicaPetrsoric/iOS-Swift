//: Playground - noun: a place where people can play

import UIKit

//func filterLesserThanValue(value: Int, numbers: [Int]) -> [Int]{
//    var filterSetOfNumbers = [Int]()
//    for num in numbers{
//        if num < value{
//            filterSetOfNumbers.append(num)
//            print(num)
//        }
//    }
//    return filterSetOfNumbers
//}

func filterWithPredicatedClosure(closure: (Int) -> Bool, numbers: [Int]) -> [Int]{
    var filteredNumbers = [Int]()
    for num in numbers{
//        perform condition check
        if closure(num){
            filteredNumbers.append(num)
        }
    }
    return numbers
}

func greaterThanThree(value: Int) -> Bool{
    return value > 3
}

func divisibleByFive(value: Int) -> Bool{
    return value % 5 == 0
}

//let filteredList = filterLesserThanValue(value: 5, numbers: [1, 2, 3, 4, 5, 10])


let filteredList = filterWithPredicatedClosure(closure: { (num) -> Bool in
    return num > 5
}, numbers: [1, 2, 3, 4, 5, 10])
print(filteredList)

let filter2 = filterWithPredicatedClosure(closure: greaterThanThree, numbers: [10, 5, 1, 2, 0])

let filter3 = filterWithPredicatedClosure(closure: divisibleByFive, numbers: [10, 5, 1, 2, 0])

