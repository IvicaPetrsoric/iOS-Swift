//: Playground - noun: a place where people can play

import UIKit

// find greatest value in list of numbers

func findGreatesValueInList(list: [Int]) -> Int?{
    if list.count == 0{
        return nil
    }
    
    var greatestValue = -1
    
    for number in list{
        if number > greatestValue{
            greatestValue = number
        }
//        print(number)
        
    }
    
    
    return -1
}


//findGreatesValueInList(list: [1, 2, 3, 1, 10, 4, 200])
findGreatesValueInList(list: [-2, -1])
[1, 2, 3].max()

