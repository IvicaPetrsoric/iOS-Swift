//: Playground - noun: a place where people can play

import UIKit

// example
// 5 + 25 * 6

// represent the equation above in tree
//      '+'
//     /   \
//   '*'    5
//   /  \
//  25   6

//node that represents a value or operator in avstract syntax tree
class Node{
    var operation: String?
    var value: Float?
    var leftChild: Node?
    var rightChild: Node?
    
    init(operation: String?, value: Float?, leftChild: Node?, rightChild: Node?) {
        self.operation = operation
        self.value = value
        self.leftChild = leftChild
        self.rightChild = rightChild
    }
}

// 6
let sixNode = Node(operation: nil, value: 6, leftChild: nil, rightChild: nil)

// 6 + 5
//  +
// 6  5
let fiveNode = Node(operation: nil, value: 5, leftChild: nil, rightChild: nil)
let plsNode = Node(operation: "+", value: nil, leftChild: sixNode, rightChild: fiveNode)


// 25 + 6 +5
//   +
//  +  5
// 25 6
let twentFiveNode = Node(operation: nil, value: 25, leftChild: nil, rightChild: nil)

let multi25_6Node = Node(operation: "*", value: nil, leftChild: twentFiveNode, rightChild: sixNode)
let rootPlusNode = Node(operation: "+", value: nil, leftChild: multi25_6Node, rightChild: fiveNode)

// implements the algorith, the above tree evalautes to 155
func evaluate(node: Node) -> Float{
    if node.value != nil{
        return node.value!
    }
    
    if node.operation == "+" {
        // applay recursion
        return evaluate(node: node.leftChild!) + node.rightChild!.value!
//        return node.leftChild!.value! + node.rightChild!.value!
    }
    
    else if node.operation == "*"{
        return evaluate(node: node.leftChild!) * node.rightChild!.value!
    }
    
    else if node.operation == "-"{
        return evaluate(node: node.leftChild!) - node.rightChild!.value!
    }
    
    else if node.operation == "/"{
        // ako jeright nula onda treba throw error!
        return evaluate(node: node.leftChild!) / node.rightChild!.value!
    }
    
    
    return 0
}


evaluate(node: rootPlusNode)
